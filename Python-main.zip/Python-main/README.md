# Python
 Códigos e exercícios resolvidos em Python
